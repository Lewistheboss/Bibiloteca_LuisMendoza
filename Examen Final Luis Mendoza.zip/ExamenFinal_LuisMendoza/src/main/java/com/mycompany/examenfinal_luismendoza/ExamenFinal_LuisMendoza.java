/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.examenfinal_luismendoza;

/**
 *
 * @author FX506HF
 */
public class ExamenFinal_LuisMendoza {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
