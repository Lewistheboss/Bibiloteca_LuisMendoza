/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package biblioteca.modelo.dao;


import biblioteca.modelo.Libro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
//AQUI LAS STRINGS
public class LibroDAO {
    // Consultas SQL
    private static final String SQL_INSERT = "INSERT INTO libros(titulo, autor, anio_publicacion) VALUES(?, ?, ?)";
    private static final String SQL_SELECT = "SELECT id, titulo, autor, anio_publicacion FROM libros";
    private static final String SQL_SELECT_BY_ID = "SELECT id, titulo, autor, anio_publicacion FROM libros WHERE id = ?";
    private static final String SQL_UPDATE = "UPDATE libros SET titulo=?, autor=?, anio_publicacion=? WHERE id=?";
    private static final String SQL_DELETE = "DELETE FROM libros WHERE id=?";
    //AÑADIR LIBRO
    public int insertar(Libro libro) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        
        try {
            conn = ConexionBD.obtenerConexion();
            stmt = conn.prepareStatement(SQL_INSERT);
            stmt.setString(1, libro.getTitulo());
            stmt.setString(2, libro.getAutor());
            stmt.setInt(3, libro.getAnioPublicacion());
            
            rows = stmt.executeUpdate();
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) ConexionBD.cerrarConexion();
        }
        
        return rows;
    }
    //SELECCIONAR LIBRO
    public List<Libro> seleccionar() throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Libro> libros = new ArrayList<>();
        
        try {
            conn = ConexionBD.obtenerConexion();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                int id = rs.getInt("id");
                String titulo = rs.getString("titulo");
                String autor = rs.getString("autor");
                int anioPublicacion = rs.getInt("anio_publicacion");
                
                libros.add(new Libro(id, titulo, autor, anioPublicacion));
            }
        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) ConexionBD.cerrarConexion();
        }
        
        return libros;
    }
    //Seleccionar ID
    public Libro seleccionarPorId(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Libro libro = null;
        
        try {
            conn = ConexionBD.obtenerConexion();
            stmt = conn.prepareStatement(SQL_SELECT_BY_ID);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                String titulo = rs.getString("titulo");
                String autor = rs.getString("autor");
                int anioPublicacion = rs.getInt("anio_publicacion");
                
                libro = new Libro(id, titulo, autor, anioPublicacion);
            }
        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) ConexionBD.cerrarConexion();
        }
        
        return libro;
    }
    //Actualizar libro
    public int actualizar(Libro libro) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        
        try {
            conn = ConexionBD.obtenerConexion();
            stmt = conn.prepareStatement(SQL_UPDATE);
            stmt.setString(1, libro.getTitulo());
            stmt.setString(2, libro.getAutor());
            stmt.setInt(3, libro.getAnioPublicacion());
            stmt.setInt(4, libro.getId());
            
            rows = stmt.executeUpdate();
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) ConexionBD.cerrarConexion();
        }
        
        return rows;
    }
    //Eliminar por ID
    public int eliminar(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        //Probar conexion SQL
        try {
            conn = ConexionBD.obtenerConexion();
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, id);
            
            rows = stmt.executeUpdate();
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) ConexionBD.cerrarConexion();
        }
        
        return rows;
    }
}