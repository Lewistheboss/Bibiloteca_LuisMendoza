/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package biblioteca.modelo.dao;

import biblioteca.modelo.Lector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LectorDAO {
    // Consultas SQL
    private static final String SQL_INSERT = "INSERT INTO lectores(nombre, email) VALUES(?, ?)";
    private static final String SQL_SELECT = "SELECT id, nombre, email FROM lectores";
    private static final String SQL_SELECT_BY_ID = "SELECT id, nombre, email FROM lectores WHERE id = ?";
    private static final String SQL_UPDATE = "UPDATE lectores SET nombre=?, email=? WHERE id=?";
    private static final String SQL_DELETE = "DELETE FROM lectores WHERE id=?";
    
    public int insertar(Lector lector) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        
        try {
            conn = ConexionBD.obtenerConexion();
            stmt = conn.prepareStatement(SQL_INSERT);
            stmt.setString(1, lector.getNombre());
            stmt.setString(2, lector.getEmail());
            
            rows = stmt.executeUpdate();
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) ConexionBD.cerrarConexion();
        }
        
        return rows;
    }
    // Seleccionar de SQL
    public List<Lector> seleccionar() throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Lector> lectores = new ArrayList<>();
        
        try {
            conn = ConexionBD.obtenerConexion();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String email = rs.getString("email");
                
                lectores.add(new Lector(id, nombre, email));
            } //SI va esto se cierra
        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) ConexionBD.cerrarConexion();
        }
        
        return lectores;
    }
    //Seleccion de id, probar conexion, poner nombre y cerrar
    public Lector seleccionarPorId(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Lector lector = null;
        
        try {
            conn = ConexionBD.obtenerConexion();
            stmt = conn.prepareStatement(SQL_SELECT_BY_ID);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                String nombre = rs.getString("nombre");
                String email = rs.getString("email");
                
                lector = new Lector(id, nombre, email);
            }
        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) ConexionBD.cerrarConexion();
        }
        
        return lector;
    }
    
    public int actualizar(Lector lector) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        
        try {
            conn = ConexionBD.obtenerConexion();
            stmt = conn.prepareStatement(SQL_UPDATE);
            stmt.setString(1, lector.getNombre());
            stmt.setString(2, lector.getEmail());
            stmt.setInt(3, lector.getId());
            
            rows = stmt.executeUpdate();
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) ConexionBD.cerrarConexion();
        }
        
        return rows;
    }
    
    public int eliminar(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        
        try {
            conn = ConexionBD.obtenerConexion();
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, id);
            
            rows = stmt.executeUpdate();
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) ConexionBD.cerrarConexion();
        }
        
        return rows;
    }
}
