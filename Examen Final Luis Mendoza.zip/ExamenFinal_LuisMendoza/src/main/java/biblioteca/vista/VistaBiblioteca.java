/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package biblioteca.vista;

import biblioteca.controlador.LectorControlador;
import biblioteca.controlador.LibroControlador;
import biblioteca.modelo.Lector;
import biblioteca.modelo.Libro;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class VistaBiblioteca {
    private Scanner scanner;
    private LibroControlador libroControlador;
    private LectorControlador lectorControlador;
    
    public VistaBiblioteca() {
        scanner = new Scanner(System.in);
        libroControlador = new LibroControlador();
        lectorControlador = new LectorControlador();
    }
    
    public void mostrarMenuPrincipal() {
        int opcion;
        do {
            System.out.println("\n=== Sistema de Gestión de Biblioteca ===");
            System.out.println("1. Gestionar Libros");
            System.out.println("2. Gestionar Lectores");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer
            
            switch (opcion) {
                case 1:
                    mostrarMenuLibros();
                    break;
                case 2:
                    mostrarMenuLectores();
                    break;
                case 3:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        } while (opcion != 3);
    }
    
    private void mostrarMenuLibros() {
        int opcion;
        do {
            System.out.println("\n--- Gestión de Libros ---");
            System.out.println("1. Agregar Libro");
            System.out.println("2. Listar Libros");
            System.out.println("3. Editar Libro");
            System.out.println("4. Eliminar Libro");
            System.out.println("5. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");
            
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer
            
            try {
                switch (opcion) {
                    case 1:
                        agregarLibro();
                        break;
                    case 2:
                        listarLibros();
                        break;
                    case 3:
                        editarLibro();
                        break;
                    case 4:
                        eliminarLibro();
                        break;
                    case 5:
                        System.out.println("Volviendo al menú principal...");
                        break;
                    default:
                        System.out.println("Opción no válida. Intente de nuevo.");
                }
            } catch (SQLException e) {
                System.out.println("Error de base de datos: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (opcion != 5);
    }
    //Agregar Libros
    private void agregarLibro() throws SQLException {
        System.out.println("\n--- Agregar Nuevo Libro ---");
        
        System.out.print("Título: ");
        String titulo = scanner.nextLine();
        
        System.out.print("Autor: ");
        String autor = scanner.nextLine();
        
        System.out.print("Año de publicación: ");
        int anioPublicacion = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        libroControlador.agregarLibro(titulo, autor, anioPublicacion);
        System.out.println("Libro agregado exitosamente!");
    }
    // Lista Libros 
    private void listarLibros() throws SQLException {
        System.out.println("\n--- Listado de Libros ---");
        List<Libro> libros = libroControlador.obtenerTodosLosLibros();
        
        if (libros.isEmpty()) {
            System.out.println("No hay libros registrados.");
        } else {
            for (Libro libro : libros) {
                System.out.println(libro);
            }
        }
    }
    //Editar Libros
    private void editarLibro() throws SQLException {
        System.out.println("\n--- Editar Libro ---");
        listarLibros();
        
        System.out.print("\nIngrese el ID del libro a editar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        Libro libro = libroControlador.obtenerLibroPorId(id);
        if (libro == null) {
            System.out.println("No se encontró un libro con ese ID.");
            return;
        }
        
        System.out.println("Editando libro: " + libro);
        
        System.out.print("Nuevo título (actual: " + libro.getTitulo() + "): ");
        String titulo = scanner.nextLine();
        
        System.out.print("Nuevo autor (actual: " + libro.getAutor() + "): ");
        String autor = scanner.nextLine();
        
        System.out.print("Nuevo año de publicación (actual: " + libro.getAnioPublicacion() + "): ");
        int anioPublicacion = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        libroControlador.actualizarLibro(id, titulo, autor, anioPublicacion);
        System.out.println("Libro actualizado exitosamente!");
    }
    // ELIMINACION!
    private void eliminarLibro() throws SQLException {
        System.out.println("\n--- Eliminar Libro ---");
        listarLibros();
        
        System.out.print("\nIngrese el ID del libro a eliminar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        Libro libro = libroControlador.obtenerLibroPorId(id);
        if (libro == null) {
            System.out.println("No se encontró un libro con ese ID.");
            return;
        }
        
        System.out.print("¿Está seguro que desea eliminar el libro " + libro.getTitulo() + "? (s/n): ");
        String confirmacion = scanner.nextLine();
        
        if (confirmacion.equalsIgnoreCase("s")) {
            libroControlador.eliminarLibro(id);
            System.out.println("Libro eliminado exitosamente!");
        } else {
            System.out.println("Operación cancelada.");
        }
    }
    //Muestreo de menu de Lectores
    private void mostrarMenuLectores() {
        int opcion;
        do {
            System.out.println("\n--- Gestión de Lectores ---");
            System.out.println("1. Agregar Lector");
            System.out.println("2. Listar Lectores");
            System.out.println("3. Editar Lector");
            System.out.println("4. Eliminar Lector");
            System.out.println("5. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");
            
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer
            //OPCIONESS
            try {
                switch (opcion) {
                    case 1:
                        agregarLector();
                        break;
                    case 2:
                        listarLectores();
                        break;
                    case 3:
                        editarLector();
                        break;
                    case 4:
                        eliminarLector();
                        break;
                    case 5:
                        System.out.println("Volviendo al menú principal...");
                        break;
                    default:
                        System.out.println("Opción no válida. Intente de nuevo.");
                }
            } catch (SQLException e) {
                System.out.println("Error de base de datos: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (opcion != 5);
    }
    //Agragacion de lector
    private void agregarLector() throws SQLException {
        System.out.println("\n--- Agregar Nuevo Lector ---");
        
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Email: ");
        String email = scanner.nextLine();
        
        lectorControlador.agregarLector(nombre, email);
        System.out.println("Lector agregado exitosamente!");
    }
    //LISTAR LECTORES
    private void listarLectores() throws SQLException {
        System.out.println("\n--- Listado de Lectores ---");
        List<Lector> lectores = lectorControlador.obtenerTodosLosLectores();
        
        if (lectores.isEmpty()) {
            System.out.println("No hay lectores registrados.");
        } else {
            for (Lector lector : lectores) {
                System.out.println(lector);
            }
        }
    }
    //EDITAR LECTORES
    private void editarLector() throws SQLException {
        System.out.println("\n--- Editar Lector ---");
        listarLectores();
        
        System.out.print("\nIngrese el ID del lector a editar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        Lector lector = lectorControlador.obtenerLectorPorId(id);
        if (lector == null) {
            System.out.println("No se encontró un lector con ese ID.");
            return;
        }
        
        System.out.println("Editando lector: " + lector);
        
        System.out.print("Nuevo nombre (actual: " + lector.getNombre() + "): ");
        String nombre = scanner.nextLine();
        
        System.out.print("Nuevo email (actual: " + lector.getEmail() + "): ");
        String email = scanner.nextLine();
        
        lectorControlador.actualizarLector(id, nombre, email);
        System.out.println("Lector actualizado exitosamente!");
    }
    //ELIMINAR LECTOR
    private void eliminarLector() throws SQLException {
        System.out.println("\n--- Eliminar Lector ---");
        listarLectores();
        
        System.out.print("\nIngrese el ID del lector a eliminar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        Lector lector = lectorControlador.obtenerLectorPorId(id);
        if (lector == null) {
            System.out.println("No se encontró un lector con ese ID.");
            return;
        }
        
        System.out.print("¿Está seguro que desea eliminar al lector " + lector.getNombre() + "? (s/n): ");
        String confirmacion = scanner.nextLine();
        
        if (confirmacion.equalsIgnoreCase("s")) {
            lectorControlador.eliminarLector(id);
            System.out.println("Lector eliminado exitosamente!");
        } else {
            System.out.println("Operación cancelada.");
        }
    }
}