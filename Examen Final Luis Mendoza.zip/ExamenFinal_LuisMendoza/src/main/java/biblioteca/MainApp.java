/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package biblioteca;

import biblioteca.vista.VistaBiblioteca;

public class MainApp {
    public static void main(String[] args) {
        // Crear instancia de la vista principal
        VistaBiblioteca vista = new VistaBiblioteca();
        
        // Iniciar la aplicación mostrando el menú principal
        vista.mostrarMenuPrincipal();
    }
}