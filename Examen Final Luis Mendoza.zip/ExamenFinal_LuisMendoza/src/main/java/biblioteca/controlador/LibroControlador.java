/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package biblioteca.controlador;
//importaciones
import biblioteca.modelo.Libro;
import biblioteca.modelo.dao.LibroDAO;
import java.sql.SQLException;
import java.util.List;

public class LibroControlador {
    private LibroDAO libroDAO;
    
    public LibroControlador() {
        libroDAO = new LibroDAO();
    }
    //Agregar libro
    public void agregarLibro(String titulo, String autor, int anioPublicacion) throws SQLException {
        Libro libro = new Libro(titulo, autor, anioPublicacion);
        libroDAO.insertar(libro);
    }
    //Sacar lista de todos los libros desde BBDD
    public List<Libro> obtenerTodosLosLibros() throws SQLException {
        return libroDAO.seleccionar();
    }
    //Obtener libro de BBDD
    public Libro obtenerLibroPorId(int id) throws SQLException {
        return libroDAO.seleccionarPorId(id);
    }
    //actualizar libro de bbdd
    public void actualizarLibro(int id, String titulo, String autor, int anioPublicacion) throws SQLException {
        Libro libro = new Libro(id, titulo, autor, anioPublicacion);
        libroDAO.actualizar(libro);
    }
    //Eliminar libro
    public void eliminarLibro(int id) throws SQLException {
        libroDAO.eliminar(id);
    }
}