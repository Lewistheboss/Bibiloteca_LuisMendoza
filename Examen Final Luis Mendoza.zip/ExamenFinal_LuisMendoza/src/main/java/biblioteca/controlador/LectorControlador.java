/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package biblioteca.controlador;
//Importaciones de biblioteca Lector y LectorDAO
import biblioteca.modelo.Lector;
import biblioteca.modelo.dao.LectorDAO;
import java.sql.SQLException;
import java.util.List;

public class LectorControlador {
    private LectorDAO lectorDAO;
    
    public LectorControlador() {
        lectorDAO = new LectorDAO();
    }
    //para agregar lector a la base de datos...
    public void agregarLector(String nombre, String email) throws SQLException {
        Lector lector = new Lector(nombre, email);
        lectorDAO.insertar(lector);
    }
    //Lista de los lectores...
    public List<Lector> obtenerTodosLosLectores() throws SQLException {
        return lectorDAO.seleccionar();
    }
    //ID de lectores...
    public Lector obtenerLectorPorId(int id) throws SQLException {
        return lectorDAO.seleccionarPorId(id);
    }
    //Actualizar lector
    public void actualizarLector(int id, String nombre, String email) throws SQLException {
        Lector lector = new Lector(id, nombre, email);
        lectorDAO.actualizar(lector);
    }
    //eliminar al compa
    public void eliminarLector(int id) throws SQLException {
        lectorDAO.eliminar(id);
    }
}
